import { Component, OnInit, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-quiz-stats',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './quiz-stats.component.html',
  styleUrl: './quiz-stats.component.scss'
})
export class QuizStatsComponent implements OnInit {
  quizId: number | null = null;
  quizStats: any = null;

  private apiUrl = 'http://localhost:8081/api/quiz';

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient
  ) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const idParam = params.get('id');
      if (idParam) {
        this.quizId = Number(idParam);
        this.loadStats(this.quizId);
      }
    });
  }

  loadStats(id: number): void {
    this.http.get<any>(`http://localhost:8081/api/quiz/stats/${id}`).subscribe({
      next: (data) => {
        this.quizStats = data;
        // 這裡直接使用後端算好的真實票數！
        setTimeout(() => this.renderRealCharts(data), 100);
      },
      error: (err) => {
        console.error('載入真實統計失敗', err);
      }
    });
  }

  renderRealCharts(statsData: any): void {
    statsData.questions.forEach((q: any, index: number) => {
      const canvasId = `chart_${index}`;
      const canvas = document.getElementById(canvasId) as HTMLCanvasElement;
      if (canvas) {
        const labels = q.options.map((opt: any) => opt.optionText);
        const data = q.options.map((opt: any) => opt.count); // 抓真實票數！

        new Chart(canvas, {
          type: 'bar',
          data: {
            labels: labels,
            datasets: [{
              label: '真實得票數',
              data: data,
              backgroundColor: ['#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b']
            }]
          },
          options: {
            responsive: true,
            scales: {
              y: {
                beginAtZero: true,
                ticks: { stepSize: 1 }
              }
            }
          }
        });
      }
    });
  }
}
