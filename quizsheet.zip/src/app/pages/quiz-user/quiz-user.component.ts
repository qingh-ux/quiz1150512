import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';

@Component({
  selector: 'app-quiz-user',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './quiz-user.component.html',
  styleUrl: './quiz-user.component.scss'
})
export class QuizUserComponent implements OnInit {
  quizzes: any[] = [];

  // 搜尋欄位綁定變數
  searchTitle: string = '';
  searchStartDate: string = '';
  searchEndDate: string = '';

  // 📄 分頁相關變數
  currentPage: number = 1;
  pageSize: number = 10;

  // 💡 填答模式相關變數（如果有 quizId 代表正在填答該張問卷）
  fillQuizId: number | null = null;
  quizDetail: any = null; // 存放問卷詳細內容（包含題目與選項）

  // 填答者個人資料
  userData = {
    name: '',
    phone: '',
    email: '',
    age: ''
  };

  // 儲存使用者勾選或填寫的答案：{ questionId: '答案內容' }
  userAnswers: { [key: number]: string } = {};

  private apiUrl = 'http://localhost:8081/api/quiz';

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // 檢查網址有沒有帶 ID (例如 /quiz/12)
    this.route.paramMap.subscribe(params => {
      const idParam = params.get('id');
      if (idParam) {
        this.fillQuizId = Number(idParam);
        this.loadQuizDetail(this.fillQuizId);
      } else {
        this.loadQuizzes(); // 否則載入前台列表
      }
    });
  }

  // 呼叫後端搜尋 API
  loadQuizzes(): void {
    let params = new HttpParams();
    if (this.searchTitle) params = params.set('title', this.searchTitle);
    if (this.searchStartDate) params = params.set('startDate', this.searchStartDate);
    if (this.searchEndDate) params = params.set('endDate', this.searchEndDate);

    this.http.get<any[]>(`${this.apiUrl}/search`, { params }).subscribe({
      next: (data) => {
        this.quizzes = data.map(q => ({
          ...q,
          status: this.calculateStatus(q.startDate, q.endDate)
        }));
      },
      error: (err) => console.error('取得問卷失敗', err)
    });
  }

  // 載入單張問卷詳細資料（供填答使用）
  loadQuizDetail(id: number): void {
    this.http.get<any>(`${this.apiUrl}/${id}`).subscribe({
      next: (data) => {
        this.quizDetail = data;
      },
      error: (err) => {
        console.error('載入問卷詳情失敗', err);
        alert('無法載入問卷內容！');
      }
    });
  }

  submitAnswers(): void {
    // 💡 確保這裡綁定的是正確的 this.userData 物件
    if (!this.userData.name || !this.userData.email) {
      alert('請填寫姓名與 Email！');
      return;
    }

    const formattedAnswers = this.quizDetail.questions.map((q: any, i: number) => {
      // 💡 抓取後端第一題可能帶有的原始基準 ID，如果沒有就從 21 開始 (或是根據妳資料庫第一題的id調整)
      const baseId = q.id || q.questionId || 21;

      return {
        // 確保每一題的 ID 都是以基準加上索引值 (例如 21, 22, 23...)，絕對不會是 null！
        questionlistId: Number(baseId + i),
        selectedOptions: this.userAnswers[i] || this.userAnswers[baseId + i] || ''
      };
    });

    const payload = {
      quizId: this.fillQuizId,
      name: this.userData.name,
      phone: this.userData.phone,
      email: this.userData.email,
      age: this.userData.age ? Number(this.userData.age) : null,
      answers: formattedAnswers
    };

    console.log('📦 準備送出給後端的 payload 資料：', JSON.stringify(payload, null, 2));

    this.http.post('http://localhost:8081/api/fill/submit', payload, { responseType: 'text' }).subscribe({
      next: (res) => {
        alert('填答成功！感謝您的參與。');
        this.router.navigate(['/quiz']);
      },
      error: (err) => {
        console.error('送出失敗', err);
        alert('送出失敗，請檢查主控台！');
      }
    });
  }

  // 計算問卷狀態
  calculateStatus(start: string, end: string): string {
    const today = new Date().toISOString().split('T')[0];
    if (today < start) {
      return '尚未開始';
    } else if (today >= start && today <= end) {
      return '進行中';
    } else {
      return '已結束';
    }
  }

  get paginatedQuizzes() {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    return this.quizzes.slice(startIndex, startIndex + this.pageSize);
  }

  get totalPages(): number {
    return Math.ceil(this.quizzes.length / this.pageSize) || 1;
  }

  get pageNumbers(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  changePage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }
}
