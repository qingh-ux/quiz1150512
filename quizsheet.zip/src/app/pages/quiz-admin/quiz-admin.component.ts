import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-quiz-admin',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './quiz-admin.component.html',
  styleUrl: './quiz-admin.component.scss'
})
export class QuizAdminComponent implements OnInit {// 👈 實作 OnInit 介面

  // 問卷基本資料
  title: string = '';
  description: string = '';
  startDate: string = '';
  endDate: string = '';
  isPreview: boolean = false;

  // 💡 新增：用來記錄目前正在編輯哪一張問卷的 ID（如果是 null 代表是「新增模式」）
  editingQuizId: number | null = null;
  private apiUrl = 'http://localhost:8081/api/quiz';

  // 📋 存放從後端撈取的所有問卷清單
  quizList: any[] = [];

  // 🚀 動態題目陣列：每一題都包含自己的編號、標題、型態與選項陣列！
  questions: any[] = [
    {
      questionNum: 1,
      title: '',
      type: 'SINGLE',
      isRequired: true,
      options: [
        { optionCode: 'A', optionText: '' },
        { optionCode: 'B', optionText: '' }
      ]
    }
  ];

  // 建構子注入 HttpClient
  constructor(private http: HttpClient) { }


  // 🚀 當畫面一載入時，自動去後端把所有問卷抓過來！
  ngOnInit() {
    this.loadQuizList();
  }

  // 1. 取得所有問卷清單的方法 (對應後端 getAllQuizzes)
  loadQuizList() {
    this.http.get<any[]>('http://localhost:8081/api/quiz/all')
      .subscribe({
        next: (data) => {
          this.quizList = data;
          console.log('成功取得問卷清單:', data);
        },
        error: (error) => {
          console.error('取得問卷清單失敗:', error);
        }
      });
  }

  // 2.刪除特定問卷的方法 (假設我們知道這張問卷的 quizId)
  //(對應後端 delete API)
  deleteQuiz(quizId: number) {
    if (confirm('確定要刪除這張問卷嗎？此動作無法復原！')) {
      this.http.delete(`http://localhost:8081/api/quiz/delete/${quizId}`, { responseType: 'text' })
        .subscribe({
          next: (response) => {
            alert('問卷已成功刪除！');
            console.log(response);
            // 刪除成功後，通常會重新整理清單或從畫面的陣列中移除該筆資料
            this.loadQuizList();
          },
          error: (error) => {
            console.error('刪除失敗:', error);
            alert('刪除失敗，請檢查主控台！');
          }
        });
    }
  }

  // 💡 點擊「編輯」按鈕時，將該筆資料帶入上方表單，並向後端取得完整題目與選項
  startEdit(quiz: any) {
    this.editingQuizId = quiz.id;
    this.title = quiz.title;
    this.description = quiz.description || '';
    this.startDate = quiz.startDate || ''; // 直接從傳入的 quiz 拿最快！
    this.endDate = quiz.endDate || '';     // 直接從傳入的 quiz 拿最快！

    // 🚀 呼叫後端我們剛寫好的完整詳情 API (GET /api/quiz/{id})
    this.http.get<any>(`${this.apiUrl}/${quiz.id}`).subscribe({
      next: (fullQuiz) => {
        // 💡 確保這裡有把後端抓回來的日期指定進去
        // 假設後端回傳的欄位叫 startDate / endDate (或 start_date)
        this.startDate = fullQuiz.startDate || quiz.startDate || '';
        this.endDate = fullQuiz.endDate || quiz.endDate || '';
        console.log('後端回傳的完整問卷資料：', fullQuiz); // 👈 可以開 F12 看這裡印出來的物件長怎樣

        // 如果後端回傳的 DTO 裡面有 questions，就把它帶入畫面
        if (fullQuiz.questions && fullQuiz.questions.length > 0) {
          this.questions = fullQuiz.questions;
        } else {
          // 如果這張問卷剛好沒有題目，給它預設一題空白的
          this.questions = [
            {
              questionNum: 1,
              title: '',
              type: 'SINGLE',
              isRequired: true,
              options: [
                { optionCode: 'A', optionText: '' },
                { optionCode: 'B', optionText: '' }
              ]
            }
          ];
        }
        console.log('成功取得問卷完整題目:', fullQuiz);
      },
      error: (err) => {
        console.error('取得問卷詳細資料失敗', err);
        alert('載入問卷題目失敗，請檢查主控台！');
      }
    });

    // 自動捲動到畫面最上方，方便開始編輯
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }


  // 💡 取消編輯，清空表單回到新增模式
  cancelEdit() {
    this.editingQuizId = null;
    this.title = '';
    this.description = '';
    this.startDate = '';
    this.endDate = '';
    this.questions = [
      {
        questionNum: 1,
        title: '',
        type: 'SINGLE',
        isRequired: true,
        options: [
          { optionCode: 'A', optionText: '' },
          { optionCode: 'B', optionText: '' }
        ]
      }
    ];
  }

  // 3. 新增題目方法
  addQuestion() {
    const newNum = this.questions.length + 1;
    this.questions.push({
      questionNum: newNum,
      title: '',
      type: 'SINGLE',
      isRequired: true,
      options: [
        { optionCode: 'A', optionText: '' },
        { optionCode: 'B', optionText: '' }
      ]
    });
  }

  // 4. 刪除題目方法
  removeQuestion(index: number) {
    if (this.questions.length > 1) {
      this.questions.splice(index, 1);
      // 刪除後重新自動編號題目序號 (1, 2, 3...)
      this.questions.forEach((q, i) => {
        q.questionNum = i + 1;
      });
    } else {
      alert('問卷至少需要保留一題喔！');
    }
  }

  // 5. 在特定題目底下新增選項
  addOption(questionIndex: number) {
    const currentOptions = this.questions[questionIndex].options;
    // 自動產生下一個代碼：A, B, C, D... (利用 ASCII 碼轉換)
    const nextCharCode = String.fromCharCode(65 + currentOptions.length);
    currentOptions.push({
      optionCode: nextCharCode,
      optionText: ''
    });
  }

  // 6. 刪除特定題目的某個選項
  removeOption(questionIndex: number, optionIndex: number) {
    const currentOptions = this.questions[questionIndex].options;
    if (currentOptions.length > 1) {
      currentOptions.splice(optionIndex, 1);
    } else {
      alert('選項至少需要保留一個！');
    }
  }

  //6A 將題目順序做調整:上移或是下移
  // 題目往上移
  moveQuestionUp(index: number) {
    if (index > 0) {
      // 跟上面那一題交換位置
      const temp = this.questions[index];
      this.questions[index] = this.questions[index - 1];
      this.questions[index - 1] = temp;

      // 交換後重新自動編號 (1, 2, 3...)
      this.questions.forEach((q, i) => {
        q.questionNum = i + 1;
      });
    }
  }

  // 題目往下移
  moveQuestionDown(index: number) {
    if (index < this.questions.length - 1) {
      // 跟下面那一題交換位置
      const temp = this.questions[index];
      this.questions[index] = this.questions[index + 1];
      this.questions[index + 1] = temp;

      // 交換後重新自動編號 (1, 2, 3...)
      this.questions.forEach((q, i) => {
        q.questionNum = i + 1;
      });
    }
  }

  // 7. 預覽功能開關
  togglePreview() {
    if (!this.title.trim()) {
      alert('完成問卷設計才可預覽，請先填入問卷主題！');
      return;
    }
    this.isPreview = !this.isPreview;
  }

  // 8. 送出整張動態問卷
  submitQuiz() {
    if (!this.title.trim()) {
      alert('請先填入問卷主題！');
      return;
    }

    // 將畫面上的動態資料直接打包送出！
    const quizData = {
      id: this.editingQuizId, // 💡 如果是編輯模式，把 ID 帶給後端
      title: this.title,
      description: this.description || "無說明",
      startDate: this.startDate || "2026-08-07",
      endDate: this.endDate || "2026-08-31",
      questions: this.questions
    };

    if (this.editingQuizId) {
      // 🔄 編輯更新模式 (假設妳後端更新的 API 路徑是 /api/quiz/update 或 /api/quiz/${this.editingQuizId})
      this.http.put(`http://localhost:8081/api/quiz/update`, quizData, { responseType: 'text' })
        .subscribe({
          next: (response) => {
            alert(`問卷：《${this.title}》已成功更新！`);
            this.cancelEdit();
            this.loadQuizList(); // 重新整理清單
          },
          error: (error) => {
            console.error('更新失敗:', error);
            alert('更新失敗，請檢查主控台！');
          }
        });
    } else {
      // ➕ 全新產出模式 (原本的邏輯)
      this.http.post('http://localhost:8081/api/quiz/create-full', quizData, { responseType: 'text' })
        .subscribe({
          next: (response) => {
            alert(`問卷：《${this.title}》已成功產出！`);
            this.cancelEdit();
            this.loadQuizList(); // 重新整理清單
          },
          error: (error) => {
            console.error('發生錯誤:', error);
            alert('產出失敗，請檢查主控台或後端狀態！');
          }
        });
    }
  }
}
