import { Routes } from '@angular/router';
import { QuizAdminComponent } from './pages/quiz-admin/quiz-admin.component';
import { QuizUserComponent } from './pages/quiz-user/quiz-user.component';
import { QuizStatsComponent } from './pages/quiz-stats/quiz-stats.component'; // 💡 1. 記得匯入統計頁面

export const routes: Routes = [
  // 開始創建路由
  { path: 'admin', component: QuizAdminComponent },
  { path: 'quiz-stats/:id', component: QuizStatsComponent }, // 💡 2. 加上這行統計路由
  { path: 'quiz', component: QuizUserComponent },
  { path: 'quiz/:id', component: QuizUserComponent }, // 💡 讓同一個元件也能處理填答頁面
  { path: '', redirectTo: 'quiz', pathMatch: 'full' }
];
